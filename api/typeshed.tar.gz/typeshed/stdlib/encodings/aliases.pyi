aliases: dict[str, str]
